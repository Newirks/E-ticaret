
<?php

include "header.php";

include "menu.php";

 ?>

  	<div class="sag-ic">


      <h2>Kategoriler</h2>


      <div class="sag-ic-tablo">
        
        <table>
          <tr class="baslik">
            <td>İl Plaka</td>
            <td>İl Adı</td>
            <td>Kargolar</td>
            <td>İşlem</td>

          </tr>
          <tr>
            <td>34</td>
            <td>İstanbul</td> 
            <td><span class="kargo">MNG</span><span class="kargo">YURTİÇİ</span></td>

            <td>
              <button type="button" class="btn btn-primary btn-xs">Düzenle</button>              
              <button type="button" class="btn btn-danger btn-xs">Sil</button> 
            </td>
          </tr>
        </table>        

      </div>






    </div>

  	<div class="temizle"></div>

<?php 

include "footer.php";

?>