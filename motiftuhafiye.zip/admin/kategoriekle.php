
<?php

include "header.php";

include "menu.php";

 ?>

  	<div class="sag-ic">


      <h2>Kategori Ekle</h2>
      <form action="" method="post" name="kategori" id="kategori">
      <input type="submit" class="btn btn-primary btn-lg urunekle" name="" value="Kategori Ekle">

      <div class="sag-ic-tablo2">
        
        <table>
          <tr>
            <td>Kategori Adı</td>
            <td><input type="text" name="kategori_adi"></td>
          </tr>
          <tr>
            <td>Kategori Grup</td>
            <td>
              <select name="kategori_grup" form="kategori">
                <option>Grup Seçiniz</option>
                <?php

                  $grup = mysqli_query($conn,"SELECT * FROM kategori_baslik");
                  while($grupliste = mysqli_fetch_array($grup)){


                    echo "<option value='".$grupliste["kategori_baslik_id"]."'>".$grupliste["kategori_baslik_adi"]."</option>";

                  }

                 ?>
              </select>
            </td>
          </tr>

        </table>        

        

      </div>
      </form>

      <?php


        if($_POST){


            $isim = $_POST["kategori_adi"];
            $grup = $_POST["kategori_grup"];


            $kategori_ekle = mysqli_query($conn,"INSERT INTO kategori_alt (kategori_alt_adi,ust_id) VALUES ('$isim','$grup')");

            if($kategori_ekle){

              header("location:kategoriler.php");

            }else{

              echo "<div style='float:right;'>Hata Oluştu</div>";
            }



        }


      ?>




    </div>

  	<div class="temizle"></div>

<?php 

include "footer.php";

?>