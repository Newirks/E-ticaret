  	<div class="sol-menu">
  		
      <ul>
        <li><a href="index.php">Anasayfa</a></li>
        <li><a href="siparis.php">Siparişler</a></li>
        <li><a href="urunler.php">Ürünler</a></li>
        <li><a href="urunekle.php">Ürün Ekle</a></li>
        <li><a href="kategoriler.php">Kategoriler</a></li>
        <li><a href="kategoriekle.php">Kategori Ekle</a></li>
        <li><a href="kategorigrup.php">Kategori Grup</a></li>
        <li><a href="kategorigrupekle.php">Kategori Grup Oluştur</a></li>
        <li><a href="kargolar.php">Kargolar</a></li>
        <li><a href="kampanyalar.php">Kampanyalar</a></li>
        <li><a href="kampanyaekle.php">Kampanya Ekle</a></li>
        <li><a href="">Siteye Dön</a></li>
        <li><a href="">Çıkış Yap</a></li>
      </ul>

  	</div>