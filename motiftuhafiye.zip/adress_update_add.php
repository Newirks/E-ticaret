<?php

include "header_main.php";

$adresid = $_GET["id"];

if($_POST["kaydetadres"]){





}elseif($_POST["kaydetfatura"]){





}else {}


include "footer.php";


 ?>