<?php 


include "data/mysql.php";

include "header.php"; 

include "banner.php";

include "menu.php";

include "menu_mob.php";

?>