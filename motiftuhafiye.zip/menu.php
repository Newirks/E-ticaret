  	<div class="hidden-xs hidden-sm container-fluid menu_alan">
  		

  			
  			<div class="row">
  				
  				<div class="col-md-12 menu">
  					
  					<ul>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/kumas.png" class="img-responsive"></center></div>
  								<span>KUMAŞLARIMIZ</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row">
  										

  										<?php

								        $kategori = mysqli_query($conn,"SELECT * FROM kategori_baslik WHERE ust_id = 0");
								        while($yaz = $kategori->fetch_array()){  	
           								$id = $yaz["kategori_baslik_id"];	
  										 ?>
  										<div class="col-md-2">
		  									<h5><?php echo $yaz["kategori_baslik_adi"]; ?></h5>

		  									<?php


									        $kategori_alt = mysqli_query($conn,"SELECT * FROM kategori_alt WHERE ust_id = '$id' ");
									        while($yaz_alt = $kategori_alt->fetch_array()){ 

		  									 ?>

		  									<p><a href="category.php?id=<?php echo $yaz_alt['kategori_alt_id']; ?>"><?php echo $yaz_alt["kategori_alt_adi"]; ?></a></p>

		  									<?php } ?>
  									 											
  										</div>

  										<?php

  										}

  										 ?>





  									</div>
  									

  								</div>
  								
  							</div>
  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/tuhafiye.png" class="img-responsive"></center></div>
  								<span>TUHAFİYE</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/firsat2.png" class="img-responsive"></center></div>
  								<span>FIRSAT ÜRÜNLERİ</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/bebek.png" class="img-responsive"></center></div>
  								<span>BEBEK ÜRÜNLER</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/perde.png" class="img-responsive"></center></div>
  								<span>PERDE KUMAŞLARI</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/parca.png" class="img-responsive"></center></div>
  								<span>PARÇA KUMAŞ</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/ev2.png" class="img-responsive"></center></div>
  								<span>EV TEKSTİLİ</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/giyim.png" class="img-responsive"></center></div>
  								<span>GİYİM</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  						<li >
  							<a href="#" class="menu_1">
  								<div><center><img src="img/menu/hobi.png" class="img-responsive"></center></div>
  								<span>HOBİ</span>
  							</a>
  							<div class="menu_2">

  								<div class="container">

  									<div class="row"></div>
  									

  								</div>
  								
  							</div>

  						</li>
  					</ul>

  				</div>

  			</div>



  	</div>