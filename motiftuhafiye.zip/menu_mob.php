  	<div class="container hidden-md hidden-lg menu_alan_mobil">
  		
  		<div class="row mob_logo_alan">
  			
  			<div class="col-sm-12 col-xs-12 ">
  				
  				<img src="img/logo.png" class="mob_logo">

  			</div>

  		</div>
  		<div class="row">
  			
  			<div class="col-sm-1 col-xs-1">
  				
			    	<a href="#" class="openBtn" onclick="openNav()"><i class="fa fa-bars"></i></a>

			    <div id="nav" class="overlay">
			    	
			    	<a href="#" class="closeBtn" onclick="closeNav()"><i class="fa fa-times"></i></a>	
			    	<ul>
			    		<li>
			    			<a href="#" onclick="openmenu()"><img src="img/menu/kumas.png" class="mob_menu_resim"> Kumaşlarımız <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a>
			    			<div id="mobilmenu" class="mobil_menu_2">
			    				<a href="#" class="backmenu" onclick="backmenu()">Geri Dön <span style="float:right;" class="glyphicon glyphicon-menu-left" aria-hidden="true"></span></i></a>
			    				<h4><img src="img/menu/kumas.png" class="mob_menu_resim"> Kumaşlarımız</h4>
			    				<ul>
			    					<li><a href="#">DİJİTAL BASKI KUMAŞ</a></li>
			    				</ul>

			    			</div>
			    		</li>
			    		<li><a href="#"><img src="img/menu/tuhafiye.png" class="mob_menu_resim"> Tuhafiye <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
			    		<li><a href="#"><img src="img/menu/firsat2.png" class="mob_menu_resim"> Fırsat Ürünleri <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
			    		<li><a href="#"><img src="img/menu/bebek.png" class="mob_menu_resim"> Bebek Ürünleri <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
			    		<li><a href="#"><img src="img/menu/perde.png" class="mob_menu_resim"> Perde Kumaşları <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
			    		<li><a href="#"><img src="img/menu/parca.png" class="mob_menu_resim"> Parça Kumaş <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li> 
 						<li><a href="#"><img src="img/menu/ev2.png" class="mob_menu_resim"> Ev Tekstil <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
 						<li><a href="#"><img src="img/menu/giyim.png" class="mob_menu_resim"> Giyim <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
 						<li><a href="#"><img src="img/menu/hobi.png" class="mob_menu_resim"> Hobi <span style="float:right;" class="glyphicon glyphicon-menu-right mob_yon" aria-hidden="true"></span></a></li>
			    	</ul>

			    </div>

  			</div>
  			<div class="col-sm-8 col-xs-8">	<input type="text" class="mob_arama" name="" placeholder="Aranacak Kelime Giriniz"></div>
  			<div class="col-sm-3 col-xs-3">
  				<a href="#"><span class="glyphicon glyphicon-user mob_icon" aria-hidden="true"></span></a>
  				<a href="#"><span class="glyphicon glyphicon-shopping-cart mob_icon" aria-hidden="true"></span></a>
  			</div>

  		</div>

  	</div>