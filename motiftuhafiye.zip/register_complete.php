<?php include "header_main.php"; ?>

<div class="container-fluid uyekayit_tamamlandi">
  
  <div class="container">
    
    <div class="row">
      
      <div class="col-md-12">
        
        <div class="uyelik_tamamladi">
          
          <img src="img/ok.png" class="img-responsive">

          <h4>Üyeliğiniz Başarılı Şekilde Tamamlanmıştır !</h4>

        </div>

      </div>

    </div>

  </div>

</div>

<?php include "footer.php"; ?>